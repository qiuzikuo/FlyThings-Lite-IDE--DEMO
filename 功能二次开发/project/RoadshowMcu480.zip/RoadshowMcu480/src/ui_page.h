/****************************************************************************
** ҳ��
**
** ÿ�α�����Ŀ���Զ��������ļ�
**
** �����ֶ��޸��ļ�����
*****************************************************************************/

#ifndef _UI_PAGE_H_
#define _UI_PAGE_H_

#define UI_PAGE_MENU                 0
#define UI_PAGE_AIR                  1
#define UI_PAGE_COFFE                2
#define UI_PAGE_COFFEWORK            3
#define UI_PAGE_COOK                 4
#define UI_PAGE_COOKWORK             5
#define UI_PAGE_OIL                  6
#define UI_PAGE_RICE                 7
#define UI_PAGE_RICEWORK             8
#define UI_PAGE_WASH                 9
#define UI_PAGE_WASH2                10
#define UI_PAGE_WASHWORK             11

#endif /*_UI_PAGE_H_*/
