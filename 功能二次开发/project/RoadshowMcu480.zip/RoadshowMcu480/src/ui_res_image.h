/****************************************************************************
** ͼƬ��Դ
**
** ÿ�α�����Ŀ���Զ��������ļ�
**
** �����ֶ��޸��ļ�����
*****************************************************************************/

#ifndef _UI_RES_IMAGE_H_
#define _UI_RES_IMAGE_H_

#define UI_RES_IMAGE_AIR_IMAGES_AIR1_03             0
#define UI_RES_IMAGE_AIR_IMAGES_AIR2_03             1
#define UI_RES_IMAGE_AIR_MAIN                       2
#define UI_RES_IMAGE_COFFE_COFFBG4                  3
#define UI_RES_IMAGE_COFFE_COFFEBG                  4
#define UI_RES_IMAGE_COFFE_COFFEMAIN4               5
#define UI_RES_IMAGE_COFFE_IMAGES_COF1_03           6
#define UI_RES_IMAGE_COFFE_IMAGES_COF1_06           7
#define UI_RES_IMAGE_COFFE_IMAGES_COF1_10           8
#define UI_RES_IMAGE_COFFE_IMAGES_COF2_03           9
#define UI_RES_IMAGE_COFFE_IMAGES_COF2_06           10
#define UI_RES_IMAGE_COFFE_IMAGES_COF2_10           11
#define UI_RES_IMAGE_COOK_COOK2                     12
#define UI_RES_IMAGE_COOK_IMAGES_COOK2_03           13
#define UI_RES_IMAGE_COOK_IMAGES_COOK2_07           14
#define UI_RES_IMAGE_COOK_IMAGES_COOK_03            15
#define UI_RES_IMAGE_COOK_IMAGES_COOK_07            16
#define UI_RES_IMAGE_COOK_IMAGES_LONGPRO1_03        17
#define UI_RES_IMAGE_COOK_IMAGES_LONGPRO_03         18
#define UI_RES_IMAGE_COOK_MAIN1                     19
#define UI_RES_IMAGE_FOOD_DIANFAN1                  20
#define UI_RES_IMAGE_FOOD_DIANFANBAO                21
#define UI_RES_IMAGE_FOOD_DIANFANBAODN              22
#define UI_RES_IMAGE_FOOD_IMAGES_COOK1_03           23
#define UI_RES_IMAGE_FOOD_IMAGES_COOK1_06           24
#define UI_RES_IMAGE_FOOD_IMAGES_COOK2_03           25
#define UI_RES_IMAGE_FOOD_IMAGES_COOK2_06           26
#define UI_RES_IMAGE_FOOD_MAIN                      27
#define UI_RES_IMAGE_LOGO_1                         28
#define UI_RES_IMAGE_LOGO_10                        29
#define UI_RES_IMAGE_LOGO_2                         30
#define UI_RES_IMAGE_LOGO_3                         31
#define UI_RES_IMAGE_LOGO_4                         32
#define UI_RES_IMAGE_LOGO_5                         33
#define UI_RES_IMAGE_LOGO_6                         34
#define UI_RES_IMAGE_LOGO_7                         35
#define UI_RES_IMAGE_LOGO_8                         36
#define UI_RES_IMAGE_LOGO_9                         37
#define UI_RES_IMAGE_WASH_MAIN1                     38
#define UI_RES_IMAGE_WASH_MAIN3                     39
#define UI_RES_IMAGE_WASH_WO0RK                     40
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN1_03     41
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN1_07     42
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN1_10     43
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN1_13     44
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN1_15     45
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN1_18     46
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN1_22     47
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN1_23     48
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN22_03    49
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN22_07    50
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN22_10    51
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN22_13    52
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN22_15    53
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN22_18    54
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN22_22    55
#define UI_RES_IMAGE_YOUYANJI_IMAGES_YOUYAN22_23    56
#define UI_RES_IMAGE_YOUYANJI_MAINBG1               57
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_0             82
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_1             83
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_2             84
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_3             85
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_4             86
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_5             87
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_6             88
#define UI_RES_IMAGE_WASH_RUN_00                    89
#define UI_RES_IMAGE_WASH_RUN_01                    90
#define UI_RES_IMAGE_WASH_RUN_02                    91
#define UI_RES_IMAGE_WASH_RUN_03                    92
#define UI_RES_IMAGE_WASH_RUN_04                    93
#define UI_RES_IMAGE_WASH_RUN_05                    94
#define UI_RES_IMAGE_WASH_RUN_06                    95
#define UI_RES_IMAGE_WASH_RUN_07                    96
#define UI_RES_IMAGE_WASH_RUN_08                    97
#define UI_RES_IMAGE_WASH_RUN_09                    98
#define UI_RES_IMAGE_WASH_RUN_10                    99
#define UI_RES_IMAGE_WASH_RUN_11                    100
#define UI_RES_IMAGE_WASH_RUN_12                    101
#define UI_RES_IMAGE_WASH_RUN_13                    102
#define UI_RES_IMAGE_WASH_RUN_14                    103
#define UI_RES_IMAGE_WASH_RUN_15                    104
#define UI_RES_IMAGE_WASH_RUN_16                    105
#define UI_RES_IMAGE_WASH_RUN_17                    106
#define UI_RES_IMAGE_WASH_RUN_18                    107
#define UI_RES_IMAGE_WASH_RUN_19                    108
#define UI_RES_IMAGE_WASH_RUN_20                    109
#define UI_RES_IMAGE_WASH_RUN_21                    110
#define UI_RES_IMAGE_WASH_RUN_22                    111
#define UI_RES_IMAGE_WASH_RUN_23                    112
#define UI_RES_IMAGE_WASH_RUN_24                    113
#define UI_RES_IMAGE_WASH_RUN_25                    114
#define UI_RES_IMAGE_WASH_RUN_26                    115
#define UI_RES_IMAGE_WASH_RUN_27                    116
#define UI_RES_IMAGE_WASH_RUN_28                    117
#define UI_RES_IMAGE_WASH_RUN_29                    118
#define UI_RES_IMAGE_WASH_RUN_30                    119
#define UI_RES_IMAGE_WASH_RUN_31                    120
#define UI_RES_IMAGE_WASH_RUN_32                    121
#define UI_RES_IMAGE_WASH_RUN_33                    122
#define UI_RES_IMAGE_WASH_RUN_34                    123
#define UI_RES_IMAGE_WASH_RUN_35                    124
#define UI_RES_IMAGE_WASH_RUN_36                    125
#define UI_RES_IMAGE_WASH_RUN_37                    126
#define UI_RES_IMAGE_WASH_RUN_38                    127
#define UI_RES_IMAGE_WASH_RUN_39                    128
#define UI_RES_IMAGE_WASH_RUN_40                    129
#define UI_RES_IMAGE_WASH_RUN_41                    130
#define UI_RES_IMAGE_WASH_RUN_42                    131

#endif /*_UI_RES_IMAGE_H_*/
