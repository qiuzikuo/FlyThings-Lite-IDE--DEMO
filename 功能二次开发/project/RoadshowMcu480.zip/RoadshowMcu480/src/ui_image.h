/****************************************************************************
** ͼƬ��Դ
**
** ÿ�α�����Ŀ���Զ��������ļ�
**
** �����ֶ��޸��ļ�����
*****************************************************************************/

#ifndef _UI_IMAGE_H_
#define _UI_IMAGE_H_

#define UI_IMAGE_AIR_IMAGES_AIR1_03             0
#define UI_IMAGE_AIR_IMAGES_AIR2_03             1
#define UI_IMAGE_AIR_MAIN                       2
#define UI_IMAGE_COFFE_COFFBG4                  3
#define UI_IMAGE_COFFE_COFFEMAIN4               4
#define UI_IMAGE_COFFE_IMAGES_COF1_03           5
#define UI_IMAGE_COFFE_IMAGES_COF1_06           6
#define UI_IMAGE_COFFE_IMAGES_COF1_10           7
#define UI_IMAGE_COFFE_IMAGES_COF2_03           8
#define UI_IMAGE_COFFE_IMAGES_COF2_06           9
#define UI_IMAGE_COFFE_IMAGES_COF2_10           10
#define UI_IMAGE_COOK_COOK2                     11
#define UI_IMAGE_COOK_IMAGES_COOK2_03           12
#define UI_IMAGE_COOK_IMAGES_COOK2_07           13
#define UI_IMAGE_COOK_IMAGES_COOK_03            14
#define UI_IMAGE_COOK_IMAGES_COOK_07            15
#define UI_IMAGE_COOK_IMAGES_LONGPRO1_03        16
#define UI_IMAGE_COOK_IMAGES_LONGPRO_03         17
#define UI_IMAGE_COOK_MAIN1                     18
#define UI_IMAGE_FONT48_UI1_03                  19
#define UI_IMAGE_FONT48_UI1_04                  20
#define UI_IMAGE_FONT48_UI1_05                  21
#define UI_IMAGE_FONT48_UI1_06                  22
#define UI_IMAGE_FONT48_UI1_07                  23
#define UI_IMAGE_FONT48_UI1_08                  24
#define UI_IMAGE_FONT48_UI1_09                  25
#define UI_IMAGE_FONT48_UI1_11                  26
#define UI_IMAGE_FONT48_UI1_12                  27
#define UI_IMAGE_FONT48_UI1_13                  28
#define UI_IMAGE_FOOD_DIANFAN1                  29
#define UI_IMAGE_FOOD_DIANFANBAO-               30
#define UI_IMAGE_FOOD_DIANFANBAODN              31
#define UI_IMAGE_FOOD_IMAGES_COOK1_03           32
#define UI_IMAGE_FOOD_IMAGES_COOK1_06           33
#define UI_IMAGE_FOOD_IMAGES_COOK2_03           34
#define UI_IMAGE_FOOD_IMAGES_COOK2_06           35
#define UI_IMAGE_FOOD_MAIN                      36
#define UI_IMAGE_WASH_MAIN1                     37
#define UI_IMAGE_WASH_MAIN3                     38
#define UI_IMAGE_WASH_WO0RK                     39
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN1_03     40
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN1_07     41
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN1_10     42
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN1_13     43
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN1_15     44
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN1_18     45
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN1_22     46
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN1_23     47
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN22_03    48
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN22_07    49
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN22_10    50
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN22_13    51
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN22_15    52
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN22_18    53
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN22_22    54
#define UI_IMAGE_YOUYANJI_IMAGES_YOUYAN22_23    55
#define UI_IMAGE_YOUYANJI_MAINBG1               56
#define UI_IMAGE_LOGO_1                         70
#define UI_IMAGE_LOGO_2                         71
#define UI_IMAGE_LOGO_3                         72
#define UI_IMAGE_LOGO_4                         73
#define UI_IMAGE_LOGO_5                         74
#define UI_IMAGE_LOGO_6                         75
#define UI_IMAGE_LOGO_7                         76
#define UI_IMAGE_LOGO_8                         77
#define UI_IMAGE_LOGO_9                         78
#define UI_IMAGE_LOGO_10                        79
#define UI_IMAGE_COFFE_IMAGES_RUN 0             80
#define UI_IMAGE_COFFE_IMAGES_RUN 1             81
#define UI_IMAGE_COFFE_IMAGES_RUN 2             82
#define UI_IMAGE_COFFE_IMAGES_RUN 3             83
#define UI_IMAGE_COFFE_IMAGES_RUN 4             84
#define UI_IMAGE_COFFE_IMAGES_RUN 5             85
#define UI_IMAGE_COFFE_IMAGES_RUN 6             86
#define UI_IMAGE_WASH_RUN-00                    87
#define UI_IMAGE_WASH_RUN-01                    88
#define UI_IMAGE_WASH_RUN-02                    89
#define UI_IMAGE_WASH_RUN-03                    90
#define UI_IMAGE_WASH_RUN-04                    91
#define UI_IMAGE_WASH_RUN-05                    92
#define UI_IMAGE_WASH_RUN-06                    93
#define UI_IMAGE_WASH_RUN-07                    94
#define UI_IMAGE_WASH_RUN-08                    95
#define UI_IMAGE_WASH_RUN-09                    96
#define UI_IMAGE_WASH_RUN-10                    97
#define UI_IMAGE_WASH_RUN-11                    98
#define UI_IMAGE_WASH_RUN-12                    99
#define UI_IMAGE_WASH_RUN-13                    100
#define UI_IMAGE_WASH_RUN-14                    101
#define UI_IMAGE_WASH_RUN-15                    102
#define UI_IMAGE_WASH_RUN-16                    103
#define UI_IMAGE_WASH_RUN-17                    104
#define UI_IMAGE_WASH_RUN-18                    105
#define UI_IMAGE_WASH_RUN-19                    106
#define UI_IMAGE_WASH_RUN-20                    107
#define UI_IMAGE_WASH_RUN-21                    108
#define UI_IMAGE_WASH_RUN-22                    109
#define UI_IMAGE_WASH_RUN-23                    110
#define UI_IMAGE_WASH_RUN-24                    111
#define UI_IMAGE_WASH_RUN-25                    112
#define UI_IMAGE_WASH_RUN-26                    113
#define UI_IMAGE_WASH_RUN-27                    114
#define UI_IMAGE_WASH_RUN-28                    115
#define UI_IMAGE_WASH_RUN-29                    116
#define UI_IMAGE_WASH_RUN-30                    117
#define UI_IMAGE_WASH_RUN-31                    118
#define UI_IMAGE_WASH_RUN-32                    119
#define UI_IMAGE_WASH_RUN-33                    120
#define UI_IMAGE_WASH_RUN-34                    121
#define UI_IMAGE_WASH_RUN-35                    122
#define UI_IMAGE_WASH_RUN-36                    123
#define UI_IMAGE_WASH_RUN-37                    124
#define UI_IMAGE_WASH_RUN-38                    125
#define UI_IMAGE_WASH_RUN-39                    126
#define UI_IMAGE_WASH_RUN-40                    127
#define UI_IMAGE_WASH_RUN-41                    128
#define UI_IMAGE_WASH_RUN-42                    129

#endif /*_UI_IMAGE_H_*/
