/****************************************************************************
** ͼƬ��Դ
**
** ÿ�α�����Ŀ���Զ��������ļ�
**
** �����ֶ��޸��ļ�����
*****************************************************************************/

#ifndef _UI_RES_IMAGE_H_
#define _UI_RES_IMAGE_H_

#define UI_RES_IMAGE_COFFE_COFFEBG0                 0
#define UI_RES_IMAGE_COFFE_COFFEBG1                 1
#define UI_RES_IMAGE_COFFE_COFFEBG2                 2
#define UI_RES_IMAGE_COFFE_IMAGES_COF1_10           3
#define UI_RES_IMAGE_COFFE_IMAGES_COF2_10           4
#define UI_RES_IMAGE_HOME_HOME1                     5
#define UI_RES_IMAGE_HOME_HOME2                     6
#define UI_RES_IMAGE_HOME_HOME3                     7
#define UI_RES_IMAGE_OIL_MAINBG1                    8
#define UI_RES_IMAGE_WASH_WASH                      9
#define UI_RES_IMAGE_WASH_WASH_ICON                 10
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_0             27
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_1             28
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_2             29
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_3             30
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_4             31
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_5             32
#define UI_RES_IMAGE_COFFE_IMAGES_RUN_6             33
#define UI_RES_IMAGE_OIL_IMAGES_YOUYAN1_10          46
#define UI_RES_IMAGE_OIL_IMAGES_YOUYAN22_10         47
#define UI_RES_IMAGE_OIL_IMAGES_YOUYAN1_07          48
#define UI_RES_IMAGE_OIL_IMAGES_YOUYAN22_07         49
#define UI_RES_IMAGE_OIL_IMAGES_YOUYAN1_13          50
#define UI_RES_IMAGE_OIL_IMAGES_YOUYAN22_13         51
#define UI_RES_IMAGE_OIL_IMAGES_YOUYAN1_03          52
#define UI_RES_IMAGE_OIL_IMAGES_YOUYAN22_03         53

#endif /*_UI_RES_IMAGE_H_*/
