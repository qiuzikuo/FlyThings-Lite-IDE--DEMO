#ifndef _LOGIC_ZK01_OIL_H_
#define _LOGIC_ZK01_OIL_H_

#include "context/guicontext.h"

#define UI_WIDGET_ZK01_OIL_NumText2             ((numtext_t*)gui_context_find_widget(3))
#define UI_WIDGET_ZK01_OIL_NumText1             ((numtext_t*)gui_context_find_widget(4))
#define UI_WIDGET_ZK01_OIL_Increment2           ((increment_t*)gui_context_find_widget(6))
#define UI_WIDGET_ZK01_OIL_Increment1           ((increment_t*)gui_context_find_widget(7))
#define UI_WIDGET_ZK01_OIL_Increment3           ((increment_t*)gui_context_find_widget(8))
#define UI_WIDGET_ZK01_OIL_Increment4           ((increment_t*)gui_context_find_widget(9))
#define UI_WIDGET_ZK01_OIL_ArtText2             ((imagetext_t*)gui_context_find_widget(13))
#define UI_WIDGET_ZK01_OIL_ArtText1             ((imagetext_t*)gui_context_find_widget(14))
#define UI_WIDGET_ZK01_OIL_ArtText3             ((imagetext_t*)gui_context_find_widget(15))
#define UI_WIDGET_ZK01_OIL_ArtText4             ((imagetext_t*)gui_context_find_widget(16))
#define UI_WIDGET_ZK01_OIL_Button2              ((button_t*)gui_context_find_widget(18))
#define UI_WIDGET_ZK01_OIL_Button1              ((button_t*)gui_context_find_widget(19))
#define UI_WIDGET_ZK01_OIL_Button3              ((button_t*)gui_context_find_widget(20))
#define UI_WIDGET_ZK01_OIL_Button4              ((button_t*)gui_context_find_widget(21))
#define UI_WIDGET_ZK01_OIL_Button5              ((button_t*)gui_context_find_widget(22))
#define UI_WIDGET_ZK01_OIL_Label2               ((label_t*)gui_context_find_widget(11))

void ui_zk01_oil_on_page_open(uint8_t page);

/**
 * @brief ��ʱ���ص��ӿ�
 * @param time   ��ʱ�����ڣ���λ ms
 * @param count  �ۼƴ���
 */
void ui_zk01_oil_on_timer(uint32_t millisecond, uint32_t count);

/**
 * @brief ��ť����¼��ص��ӿ�
 * @param button   ��ť�ؼ�ָ��
 * @param type     �����¼�����
 */
void ui_zk01_oil_on_button_touch_event(button_t *button, touch_type_e type);

/**
 * @brief �������ص��ӿ�
 * @param progress  �������ؼ�ָ��
 * @param val       ����ֵ
 */
void ui_zk01_oil_on_progress_changed(progress_t *progress, uint16_t val);

/**
 * @brief �������Ž����ص��ӿ�
 * @param animation  �����ؼ�ָ��
 */
void ui_zk01_oil_on_animation_play_end(animation_t *animation);

#endif /*_LOGIC_ZK01_OIL_H_*/
