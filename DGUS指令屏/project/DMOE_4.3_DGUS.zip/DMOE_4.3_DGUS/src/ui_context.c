#include "context/guicontext.h"

#include "logic/zk00home.h"
#include "logic/zk01oil.h"
#include "logic/zk02coffe.h"
#include "logic/zk03coffe2.h"
#include "logic/zk04wash.h"

/**
 * @brief ��ʱ���ص��ӿ�
 * @param millisecond   ��ʱ�����ڣ���λ ms
 * @param count  �ۼƴ���
 */
void on_timer(uint32_t millisecond, uint32_t count) {
  typedef void (*Callback)(uint32_t millisecond, uint32_t count);
  const Callback callbacks[] = {
    ui_zk00home_on_timer,
    ui_zk01oil_on_timer,
    ui_zk02coffe_on_timer,
    ui_zk03coffe2_on_timer,
    ui_zk04wash_on_timer
  };
  (callbacks[gui_context_get_current_page()])(millisecond, count);
}

/**
 * @brief ҳ��򿪻ص��ӿ�
 * @param page   ҳ��ID
 */
void on_page_open(uint8_t page) {
  typedef void (*Callback)();
  const Callback callbacks[] = {
    ui_zk00home_on_page_open,
    ui_zk01oil_on_page_open,
    ui_zk02coffe_on_page_open,
    ui_zk03coffe2_on_page_open,
    ui_zk04wash_on_page_open
  };
  (callbacks[page])();
}

/**
 * @brief ��ť����¼��ص��ӿ�
 * @param button   ��ť�ؼ�ָ��
 * @param type     �����¼�����
 */
void on_button_touch_event(button_t *button, touch_type_e type) {
  typedef void (*Callback)(button_t *button, touch_type_e type);
  const Callback callbacks[] = {
    ui_zk00home_on_button_touch_event,
    ui_zk01oil_on_button_touch_event,
    ui_zk02coffe_on_button_touch_event,
    ui_zk03coffe2_on_button_touch_event,
    ui_zk04wash_on_button_touch_event
  };
  (callbacks[gui_context_get_current_page()])(button, type);
}

/**
 * @brief �������ص��ӿ�
 * @param progress  �������ؼ�ָ��
 * @param val       ����ֵ
 */
void on_progress_changed(progress_t *progress, uint16_t val) {
  typedef void (*Callback)(progress_t *progress, uint16_t val);
  const Callback callbacks[] = {
    ui_zk00home_on_progress_changed,
    ui_zk01oil_on_progress_changed,
    ui_zk02coffe_on_progress_changed,
    ui_zk03coffe2_on_progress_changed,
    ui_zk04wash_on_progress_changed
  };
  (callbacks[gui_context_get_current_page()])(progress, val);
}

/**
 * @brief �������Ž����ص��ӿ�
 * @param animation  �����ؼ�ָ��
 */
void on_animation_play_end(animation_t *animation) {
  typedef void (*Callback)(animation_t *animation);
  const Callback callbacks[] = {
    ui_zk00home_on_animation_play_end,
    ui_zk01oil_on_animation_play_end,
    ui_zk02coffe_on_animation_play_end,
    ui_zk03coffe2_on_animation_play_end,
    ui_zk04wash_on_animation_play_end
  };
  (callbacks[gui_context_get_current_page()])(animation);
}
